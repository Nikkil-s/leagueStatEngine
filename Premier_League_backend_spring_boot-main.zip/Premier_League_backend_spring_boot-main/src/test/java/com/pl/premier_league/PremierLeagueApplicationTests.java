package com.pl.premier_league;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PremierLeagueApplicationTests {

	@Test
	void contextLoads() {
	}

}
